import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SearchPlayerComponent } from './component/search-player/search-player.component';
import { SearchProfileService } from './service/search-profile.service';
import { SearchBarComponent } from './component/search-bar/search-bar.component';
import { HttpClientModule } from '@angular/common/http';
import { PlayerDetailsComponent } from './component/player-details/player-details.component';

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      HttpClientModule,
     
      RouterModule.forChild([
        {
          path: '',
          component: SearchPlayerComponent,
        }
  
      ])],
    declarations: [
        SearchPlayerComponent,
        SearchBarComponent,
        PlayerDetailsComponent
      
    ],
    providers: [SearchProfileService]
  })
  export class SearchModule { }
  