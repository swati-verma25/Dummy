import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { SearchProfileService } from '../../service/search-profile.service';
import { ProfileModel } from '../models/profile.model';

@Component({
  selector: 'app-player-details',
  templateUrl: './player-details.component.html',
  styleUrls: ['./player-details.component.less']
})
export class PlayerDetailsComponent implements OnInit,OnChanges {
  @Input() playerData:any;
  constructor(private service:SearchProfileService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes['playerData'].currentValue){
      this.playerData=changes['playerData'].currentValue;
    }
  }
  
}
