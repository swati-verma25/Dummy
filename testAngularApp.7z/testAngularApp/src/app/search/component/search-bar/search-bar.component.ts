import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { SearchProfileService } from '../../service/search-profile.service';

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.less']
})
export class SearchBarComponent implements OnInit {
 searchName:string=''; 
 @Output() search: EventEmitter<any> = new EventEmitter<any>();
  constructor(private searchProfileService:SearchProfileService) { }

  ngOnInit(): void {
  }

  searchProfile(){
    if(this.searchName){
      this.searchProfileService.validatePlayer(this.searchName).subscribe(profile=>{
        if(profile  && profile.active==='true'){
          this.searchProfileService.getProfileDetail(profile.profileId).subscribe(
            result=>{
              this.search.emit({profileDetails:result,profile:profile});
            }
          )
        }
    
  });
  }

  }
}
