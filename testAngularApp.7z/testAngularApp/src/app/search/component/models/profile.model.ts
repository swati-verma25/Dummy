export class ProfileModel {
   
    id?: string;
    active?: string;
    profileId?: string;
    public static mapToModel(data:any): ProfileModel {

        let profile = new ProfileModel();
        if(data){
            profile.id=data.id;
            profile.active=data.active,
            profile.profileId=data["profile-id"]; 
        }
        return profile
    }
}