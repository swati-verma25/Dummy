import { Component, OnInit } from '@angular/core';
import { SearchProfileService } from '../../service/search-profile.service';
import { ProfileDetailsModel } from '../models/profile-details.model';
import { ProfileModel } from '../models/profile.model';

@Component({
  selector: 'app-search-player',
  templateUrl: './search-player.component.html',
  styleUrls: ['./search-player.component.less']
})
export class SearchPlayerComponent implements OnInit {
  profieData:ProfileDetailsModel | undefined ;

  profile:ProfileModel| undefined;
  constructor(private service:SearchProfileService) { }

  ngOnInit(): void {
  }

  searchPlayer(data:any){
  if(data ){
   this.profieData=data.profileDetails;
   this.profile=data.profile}
  }
}
