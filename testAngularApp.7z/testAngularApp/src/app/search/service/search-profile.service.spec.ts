import { TestBed } from '@angular/core/testing';

import { SearchProfileService } from './search-profile.service';

describe('SearchProfileService', () => {
  let service: SearchProfileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchProfileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
