import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProfileModel } from '../component/models/profile.model';
import { ProfileDetailsModel } from '../component/models/profile-details.model';

@Injectable()
export class SearchProfileService {

  constructor(private httpClient:HttpClient) { }

  validatePlayer(name:string):Observable<ProfileModel>{   
   
   var activeProfileUrl=`https://web-sandbox.onefootball.com/assignments/player/data/${name}.json`;
  
    return this.httpClient.get<ProfileModel>(activeProfileUrl).pipe(map((response) => {
      return ProfileModel.mapToModel(response.valueOf());
    }));
    }

    getProfileDetail(profileId:string | undefined):Observable<ProfileDetailsModel>{   
   
      var profileUrl=`https://web-sandbox.onefootball.com/assignments/player/profile/${profileId}`;
     
       return this.httpClient.get<ProfileDetailsModel>(profileUrl);
       }
}
